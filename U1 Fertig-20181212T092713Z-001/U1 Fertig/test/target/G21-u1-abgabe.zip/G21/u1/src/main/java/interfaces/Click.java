package interfaces;

import java.io.IOException;
import java.rmi.RemoteException;

public interface Click {
    public void OnClick() throws IOException;
}
